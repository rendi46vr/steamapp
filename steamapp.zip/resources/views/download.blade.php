<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <!-- <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'> -->
    <style>
        .page-break {
            page-break-after: always;
        }

        body {
            font-family: Arial, sans-serif;
            width: 80mm;
            height: 120mm;
            margin: 0;
            padding: 10px;
        }

        .header {
            text-align: center;
            font-size: 16px;
            line-height: 1.5px;
        }

        p.c {
            font-size: 12px;
            margin-bottom: 20px;
            line-height: 12px;
            text-align: center;
        }

        .footer {
            margin-top: 20px;
            font-size: 12px;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
        }

        .img {
            display: flex;
            justify-content: center;
        }

        .info-table {
            font-size: 12px;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <?php

    use SimpleSoftwareIO\QrCode\Facades\QrCode;
    use Illuminate\Support\Facades\Storage;

    $i = 0;
    $count = $tikets->count();

    ?>
    @foreach($tikets as $tiket)
    <?php $i++; ?>
    <div class="tiket @if($i != $count)page-break @endif">
        <div class="header ">
            <h2>Steam App</h2>
            <p class="c">Alamat: Jl. Contoh No. 123, Kota Contoh</p>
        </div>
        <div class="img">
            {{ QrCode::size(150)->generate($tiket->id)}}
        </div>

        <p class="c" style="margin-bottom: 0px;">{{$tjual->np}}</p>

        <p class="c" style="margin-bottom: 0px;"> {{$tjual->plat}}</p>
        @if($tiket->status == 1)
        <p class="c" style="font-weight: 600; margin-top: 1px;"> (Terpakai)</p>
        @endif
        <div class="footer">
            <p><strong>Phone:</strong> <br> 987-654-3210</p>
            <p><strong>Email :</strong> <br> customer@email.com</p>
        </div>
    </div>
    @endforeach
</body>

</html>